## Direct Line Speech Client Changelog

<a name="x.y.z"></a>
# 1.0.0 (2019-07-08)

First open-source drop

﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

namespace DLSpeechClient
{
    using System.Windows.Controls;
    
    /// <summary>
    /// Interaction logic for ConversationView.xaml.
    /// </summary>
    public partial class ConversationView : UserControl
    {
        public ConversationView()
        {
            this.InitializeComponent();
        }
    }
}
